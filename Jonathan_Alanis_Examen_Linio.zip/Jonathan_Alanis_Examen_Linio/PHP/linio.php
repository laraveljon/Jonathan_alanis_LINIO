<?php
   
   function Linio(){

    $dat = 100;

        for ($i=1; $i <= $dat ; $i++) { 
        echo "<tr  >";  
            if($i % 15==0)
            echo "<td>".'LINIANO'."</td>";
            else if($i % 3 == 0)
            echo "<td>".'Linio'."</td>";
            else  if($i % 5 == 0)
            echo "<td>".'IT'."<td>";
            else 
            echo "<td>".$i."</td>";
            //echo "<br>";
            echo "</tr>";
        }

   }



   Linio();

 ?>