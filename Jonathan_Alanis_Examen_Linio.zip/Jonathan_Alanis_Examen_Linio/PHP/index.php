<!--

  # Challenge - Backend Developer
Write a program that prints all the numbers from 1 to 100. However, for multiples of 3,
 instead of the number, print "Linio". For multiples of 5 print
"IT". For numbers which are multiples of both 3 and 5, print "Linianos".
# Requirements:
* Unit tests
* You can write the challenge in any language you want. Here at Linio we are big fans of PHP, Kotlin and TypeScript
# Submission:
You can create a public repository on your GitHub account and send the link to us, or just send us a zip file.

  Name : Jonathan Alanis Rojas
 -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
  
    <title>Examen Linio</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <style>
        table { border-collapse;}
        table tbody tr { background-color: #f50; }
        table tbody tr:hover { background-color: #ffffff; }

        table tbody td { border: 2px; solid #fff; padding: 5px; text-align: center; }
        table tbody td : last-child, table thead th: last-child { border-right: 0px; }


    </style>

</head>
<body>
<center>
   <div class="container-fluid"> <h1 >Examen de Linio  Jonathan Alanis Rojas</h1></div> 
<table>
<tbody class='active'>

<?php    
include_once 'linio.php';
?>
 </tbody>
</table>
</center>    
</body>
</html>